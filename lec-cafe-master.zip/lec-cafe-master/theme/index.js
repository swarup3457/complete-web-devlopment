module.exports = (themeConfig, ctx) => {
  console.log(themeConfig)
  return {
    extend: '@vuepress/theme-default'
  }
}
