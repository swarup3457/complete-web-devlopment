# Database と Eloquent の活用

![](/images/leccafe.png)

## 概要 

Eloquent を利用した Laravel での Database 管理を行います。

Laravel の Migration や Seeder を利用したデータベース管理に加え、
内部で Eloquent を使用しながら Eloquent の様々な クエリ操作を体験してみましょう。

