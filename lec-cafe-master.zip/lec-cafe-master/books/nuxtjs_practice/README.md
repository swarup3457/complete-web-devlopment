## Nuxt.jsによるSPA開発実践編

[![Netlify Status](https://api.netlify.com/api/v1/badges/eeb8e99b-eedd-4e40-b3c4-c53c42cb53fd/deploy-status)](https://app.netlify.com/sites/books-nuxtjs-practice/deploys)

https://nuxtjs-practice.lec.cafe/

## Usage

install dependency

```bash
$ npm i 
```

launch local server

```bash
$ npm run docs:dev
```

