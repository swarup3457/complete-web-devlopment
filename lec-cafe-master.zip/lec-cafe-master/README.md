# lec-cafe
[![Netlify Status](https://api.netlify.com/api/v1/badges/1403bae0-1bec-4148-aa8b-a30d906f73a1/deploy-status)](https://app.netlify.com/sites/lec-cafe-lessons/deploys)

https://docs.google.com/spreadsheets/d/1yCvZuo9pEQM3zXQn81zNbBa1KStm8zID2hw5kfZ7xuk/edit#gid=891965617

## netlify 

https://lessons.lec.cafe/

## setup

```bash
$ npm i -g vuepress
```


## Usage

該当の資料の `.vuepress` フォルダがある場所までのパスを指定します。

```bash
$ npm run dev -- books/{編集するフォルダ}
```

