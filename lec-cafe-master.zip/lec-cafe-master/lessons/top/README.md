---
layout: TopPage
lessons: 
  /laravel_graphql:
    title: Laravel GraphQL 開発 入門
    description: Laravel と lighthouse を利用して GraphQL を作成するための 入門講座です。
  /nuxtjs_website:
    title: Nuxt.js で始める Webサイト制作
    description: Nuxt.js で始める Webサイト制作の入門講座です。
  /nuxtjs_forms:
    title: Nuxt.js で作るバリデーションフォーム
    description: |
      Nuxt.js と vuelidate を利用して、バリデーション付きのフォームを作成する方法を紹介します。
---

