module.exports = require("../../config")("nuxtjs_website")
