module.exports = require("../../config")("nuxtjs_blog")
