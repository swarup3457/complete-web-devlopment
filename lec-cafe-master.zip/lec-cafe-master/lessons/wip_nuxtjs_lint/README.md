# Nuxt.js/Vue.jsで作るWebサイト入門

![](/images/leccafe.png)

DEMO


SAMPLE REPOSITORY

https://github.com/lec-cafe/sample_laravel_graphql


## Contents

### eslintのセットアップ

### eslintのルールカスタマイズ

no-v-htmlなどを例に

### scoped cssであれする

カスタムルールの追加

### eslintの自動化

### huskyでコミットフック

### github actionsでCI化

### stylelintの導入

### stylelintでBEMの制御

### stylelintで詳細度の制御



