module.exports = require("../../config")("nuxtjs_forms")
// module.exports = {}

//const commonConfig = require("../../../libs/common.config")
//
//module.exports = {
//  ...commonConfig,
//  base: "/nuxtjs_forms/",
//  dest: "dist/nuxtjs_forms",
//  title: 'Nuxt.js で始める Webサイト制作',
//  description: 'Nuxt.js で始める Webサイト制作の入門講座です。',
//  themeConfig: {
//    ...commonConfig.themeConfig,
//    sidebar: [
//      '/01.setup',
//      '/02.model',
//      '/03.validation',
//      '/04.validation2.md',
//      '/05.errors.md',
//      '/06.components.md',
//    ],
//    docsDir: 'lessons/nuuxtjs_website',
//  }
//}
//
